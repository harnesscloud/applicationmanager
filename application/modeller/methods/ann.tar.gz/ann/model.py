#!/usr/bin/env python
#from application.predictor.basemodel import BaseModel
import neuralnetwork as ann
#import math

print ann.__dict__
print ann.create(3,[3,2,3])
print "success"
                 
# class ANNmodel(BaseModel):
#     
#     NumNeurons = 3
#     NumHiddenLayers = 1
#     
#     def train(self):
#         pass
# 
#     def test(self, inputs, outputs):
#         
#         predicted_output = self.model.predict(inputs)  
#         
#         square_dif = map(lambda i: (outputs[i] - predicted_output[i])**2, range(len(predicted_output)))
#         
#         standard_deviation = math.sqrt(reduce(lambda x, y : x + y, square_dif) / len(predicted_output)) 
#         print predicted_output            
#         print outputs
#         print "SD :", standard_deviation
#         return standard_deviation
# 
#     def __predict(self):
#         pass