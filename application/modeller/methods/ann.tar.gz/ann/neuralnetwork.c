#include <Python.h>
#include "fann.h" 
#include <stdio.h>


const float desired_error = (const float) 10.000;
const unsigned int max_epochs = 10000;
const unsigned int epochs_between_reports = 5000;
const fann_type min_weight = -0.2;
const fann_type max_weight = 0.2;


struct fann *ann;
 
 
 struct fann * _create(const unsigned int units_per_layer, unsigned int* layers)
 {
 	//create network
    ann = fann_create_standard_array(units_per_layer, layers);
    
    fann_set_training_algorithm(ann, FANN_TRAIN_RPROP);
    
    fann_set_activation_function_hidden(ann, FANN_LINEAR);
    fann_set_activation_function_output(ann, FANN_LINEAR);
    fann_randomize_weights(ann, min_weight, max_weight);
	fann_set_learning_momentum(ann,0.03);
 	fann_set_learning_rate(ann, 0.9);
    fann_print_connections(ann);

 	fann_get_training_algorithm(ann);
 
 	printf("OK");
 	
 	return ann;
 }
 
 void _train(struct fann_train_data *data)
 {
 	//train network
    fann_train_on_data(ann, data, max_epochs,epochs_between_reports, desired_error);
    //save network in file
    //fann_save(ann, *(argv + 1));
 
 }
 
 
 int _predict(int n)
 {
 	return n;
 }
 
 
 void _destroy(void)
 {
 	fann_destroy(ann);
 }
 
 
static PyObject*
create(PyObject* self, PyObject* args)
{
	const unsigned int units_per_layer;
 	unsigned int* layers;
    if (!PyArg_ParseTuple(args, "units_per_layer", &units_per_layer))
        return NULL;
        
    
	if (!PyArg_ParseTuple(args, "layers", &layers))
        return NULL;
        
    return Py_BuildValue("ann", _create(units_per_layer, layers));
}


static PyObject * train(PyObject* self, PyObject* args)
{
    struct 	fann_train_data 	* data;
 
    PyArg_ParseTuple(args, "data", &data);
 
    _train(data);
    Py_RETURN_NONE;
}


static PyObject*
predict(PyObject* self, PyObject* args)
{
    int n;
 
    if (!PyArg_ParseTuple(args, "i", &n))
        return NULL;
 
    return Py_BuildValue("result", _predict(n));
}


static PyObject * destroy(PyObject* self, PyObject *args)
{
    _destroy();
    Py_RETURN_NONE;
}
 
static PyMethodDef ANNMethods[] = {
    {"create", create, METH_VARARGS, "Create a neural network."},
    {"train", train, METH_VARARGS, "Train the neural network."},
    {"predict", predict, METH_VARARGS, "Predict the output."},
    {"destroy", destroy, METH_VARARGS, "Destroy the neural network."},
    {NULL, NULL, 0, NULL},
};

 
PyMODINIT_FUNC
initneuralnetwork(void)
{
    (void) Py_InitModule("neuralnetwork", ANNMethods);
}


